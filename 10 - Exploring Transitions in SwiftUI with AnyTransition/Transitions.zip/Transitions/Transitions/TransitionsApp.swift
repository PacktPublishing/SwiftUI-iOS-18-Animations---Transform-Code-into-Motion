//
//  TransitionsApp.swift
//  Transitions
//
//  Created by Ron Erez on 02/12/2024.
//

import SwiftUI

@main
struct TransitionsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
