//
//  Logo_Splash_Screen_DemoApp.swift
//  Logo Splash Screen Demo
//
//  Created by Ron Erez on 29/11/2024.
//

import SwiftUI

@main
struct Logo_Splash_Screen_DemoApp: App {
    var body: some Scene {
        WindowGroup {
            MainLogoView()
        }
    }
}
