
struct LogoPhaseModel {
    let y: Double
    let showText: Bool
    let percentage: Double
    let ellipseScale: Double
    let logoScale: Double
}
