//
//  Blob_Splash_ScreenApp.swift
//  Blob Splash Screen
//
//  Created by Ron Erez on 29/11/2024.
//

import SwiftUI

@main
struct Blob_Splash_ScreenApp: App {
    var body: some Scene {
        WindowGroup {
            MainAppView()
        }
    }
}
